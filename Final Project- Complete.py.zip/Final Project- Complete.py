#!/usr/bin/env python
# coding: utf-8

# # Bike Count Dataset

# Prediction of hourly bike rental count based on environmental and seasonal settings 
# 
# Columns: 
# seasons : season(1= winter, 2 = spring, 3= summer, 4 = fall)
# weather : 1 = clear, 2= mist/cloudy, 3 = light snow, 4 = heavy rain
# yr : year (0= 2011, 1 = 2012)
# mnth: month (1 to 12) 
# hr : hour (0 to 23) 
# Temp : Temp in Celsius, 41 max
# aTemp : feeling temp in Celsius, 50 max
# windspeed: 67 max
# casual: count of casual users 
# registered: count of registered users 
# cnt: total count o bike rentals both casual and registered users

# # Import libraries 

# In[1]:


import numpy as np
import pandas as pd
import seaborn as sns
import scipy 
import statsmodels
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.multicomp import MultiComparison
from statsmodels.stats.proportion import proportions_ztest
from statsmodels.stats.proportion import proportions_chisquare
import matplotlib.pyplot as plt
from pylab import *
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
import statsmodels.api as sm
import statsmodels.stats.api as sms
from scipy.stats import boxcox
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn import metrics


# # Load Dataset

# In[2]:


hour = pd.read_csv('/Users/briellewoodson/Documents/Final Project/hour.csv')


# In[3]:


hour.head()


# In[4]:


hour.describe()


# # Data Wrangling/Analysis

# In[7]:


hour.info()


# In[8]:


hour.columns


# In[9]:


len(hour)


# In[10]:


len(hour.columns)


# In[11]:


hour1= hour.drop(['mnth','yr','hr','holiday','weekday','workingday','casual'], axis=1)


# In[12]:


hour1.dtypes


# In[13]:


hour1.head()


# In[14]:


hour1.tail()


# In[15]:


hour1.sample(50)


# In[16]:


hour1.describe()


# In[17]:


hour1.cnt.value_counts()


# In[18]:


hour1.registered.value_counts()


# In[19]:


hour1.mean()


# In[20]:


hour1.median()


# In[21]:


###No categorical data, no need for recoding 


# # Check distribution of variables with graphs and detect any outliers

# In[22]:


hour1.hist()


# In[23]:


hour1.cnt.hist()


# In[24]:


sns.heatmap(hour1.corr(), cbar=True, linewidths=0.5)


# In[23]:


sns.pairplot(hour1)


# In[25]:


#LM plot function to see linear relationship
sns.lmplot(x='cnt', y='season', data=hour1)


# In[25]:


#linear regression line lands on season 3


# In[26]:


#Look for outliers using boxplots
sns.boxplot(x='season', y='cnt', data=hour1)


# In[1]:


#Based on the linear regression models used, the time when people are renting the most bikes are during the spring.


# In[34]:


x = hour1[['season', 'weathersit']]
y = hour1['cnt']


# In[35]:


x_train, x_test, y_train, y_test = train_test_split(x,y, test_size = .4, random_state=101)


# In[36]:


print(x_train.shape, y_train.shape)
print(x_test.shape, y_test.shape)


# In[37]:


#Linear Regression 
lm = LinearRegression()
lm.fit(x_train, y_train)
LinearRegression()


# In[38]:


predictions = lm.predict(x_test)
predictions


# In[39]:


plt.scatter(y_test, predictions)


# In[40]:


print("Score:", lm.score(x_test, y_test))


# In[41]:


#Model is 5% accurate; predictions cannot be completely based on these models since the accuracy is so low. 


# In[ ]:




